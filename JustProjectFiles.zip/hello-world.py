# Import sleep function from time module for sleep command
from time import sleep

# Print to screen and ask user for name
print('Good day!')
name = input('What is your name? ')

# print Hello and the user's name
print('Hello, ' + name + '!')

# Sleep for 5 seconds
sleep(5)
